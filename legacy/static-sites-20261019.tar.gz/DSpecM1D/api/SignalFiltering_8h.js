var SignalFiltering_8h =
[
    [ "DSpecM::FilterOptions", "structDSpecM_1_1FilterOptions.html", "structDSpecM_1_1FilterOptions" ],
    [ "DSpecM::FilterResult", "structDSpecM_1_1FilterResult.html", "structDSpecM_1_1FilterResult" ],
    [ "applyFilter", "SignalFiltering_8h.html#ace67b3c95c9088eb9adfb7f4ac829b73", null ],
    [ "applyFilter", "SignalFiltering_8h.html#a1551f53e31d590a0304f994940cf50f9", null ]
];