var classSPARSESPEC_1_1SpectraRunContext =
[
    [ "SpectraRunContext", "classSPARSESPEC_1_1SpectraRunContext.html#a5c8cc8b02ece380b17db2bbc3044c4e7", null ],
    [ "SpectraRunContext", "classSPARSESPEC_1_1SpectraRunContext.html#a1c861a5c76eebd5a4a5af792f9ba38c8", null ],
    [ "cmt", "classSPARSESPEC_1_1SpectraRunContext.html#aee31373bed88e6e301a649020cc8732f", null ],
    [ "freqFull", "classSPARSESPEC_1_1SpectraRunContext.html#a6db4dcd9520f5d137240b9a2d2b7d507", null ],
    [ "nskip", "classSPARSESPEC_1_1SpectraRunContext.html#ab7cb42feadf25828d42adca90f45791b", null ],
    [ "params", "classSPARSESPEC_1_1SpectraRunContext.html#ada39bfe64e64f0da7562fc76429ec9df", null ],
    [ "tref", "classSPARSESPEC_1_1SpectraRunContext.html#a1bea3ce7ea1bbdd2b51689d4720b0b8e", null ]
];