var structSPARSESPEC_1_1SpecConstants =
[
    [ "SpecConstants", "structSPARSESPEC_1_1SpecConstants.html#a61b20a6ad212c6bef680e4fc8300cb39", null ],
    [ "ieps", "structSPARSESPEC_1_1SpecConstants.html#a3a57f02c98923fcb6e217f7ea18c9205", null ],
    [ "myi", "structSPARSESPEC_1_1SpecConstants.html#ad7875428d9919f0459498ef1f3b5a109", null ],
    [ "twodivpi", "structSPARSESPEC_1_1SpecConstants.html#a03c6a38b06ac3eb9b2c525669c041e9f", null ],
    [ "twopid", "structSPARSESPEC_1_1SpecConstants.html#a4987f8d7e4aefaaf15ea675ff96344ba", null ],
    [ "w0", "structSPARSESPEC_1_1SpecConstants.html#ae4ed4f9fd27cbb99d24fa7db54c89f86", null ]
];