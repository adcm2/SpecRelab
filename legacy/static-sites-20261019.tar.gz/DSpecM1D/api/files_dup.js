var files_dup =
[
    [ "DSpecM1D", "dir_711f3d458b30e23dc338fd1104553c89.html", "dir_711f3d458b30e23dc338fd1104553c89" ],
    [ "tutorials", "dir_0d353d24d0afa59909efab6593124f6d.html", "dir_0d353d24d0afa59909efab6593124f6d" ]
];