var namespaceSpectraSolver =
[
    [ "FreqFull", "classSpectraSolver_1_1FreqFull.html", "classSpectraSolver_1_1FreqFull" ]
];