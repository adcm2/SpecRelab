var classYSPECREADER_1_1DataColumns =
[
    [ "DataColumns", "classYSPECREADER_1_1DataColumns.html#afcd58ec270c4d43d318c4b7a332a5c5f", null ],
    [ "DataColumns", "classYSPECREADER_1_1DataColumns.html#af97b29e576322cf45607ecfebf20b53c", null ],
    [ "clear", "classYSPECREADER_1_1DataColumns.html#af62a4263b871cb99e89097ad7eff0f33", null ],
    [ "getColumn1", "classYSPECREADER_1_1DataColumns.html#aac90e0dcbb9792d028d8413b8a1a77a7", null ],
    [ "getColumn2", "classYSPECREADER_1_1DataColumns.html#a79c291d7dc269d917506aee4d3a90de5", null ],
    [ "getColumn3", "classYSPECREADER_1_1DataColumns.html#ac18da07e8bbcb7351d9af01e95d1688c", null ],
    [ "getColumn4", "classYSPECREADER_1_1DataColumns.html#a8613ba8491f20e85215f7b678d034c47", null ]
];