var structDSpecM_1_1FilterResult =
[
    [ "frequencySeries", "structDSpecM_1_1FilterResult.html#ad389b2fcca1571c85571dec227a85d12", null ],
    [ "timeSeries", "structDSpecM_1_1FilterResult.html#aeddbf0aa062db082addb65c27b040c35", null ]
];