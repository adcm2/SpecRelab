var classMINEOSREADER_1_1DataColumns =
[
    [ "DataColumns", "classMINEOSREADER_1_1DataColumns.html#a57d401b1ef10b28ec2562fb199c14f3c", null ],
    [ "DataColumns", "classMINEOSREADER_1_1DataColumns.html#a665cf8a61add9cd0d5a89063714c338c", null ],
    [ "clear", "classMINEOSREADER_1_1DataColumns.html#a4e0f18fab17e05e5de4bf3b2fd4e52d0", null ],
    [ "getColumn1", "classMINEOSREADER_1_1DataColumns.html#a5a11ef410c9fef4e23fee4c5050fd76d", null ],
    [ "getColumn2", "classMINEOSREADER_1_1DataColumns.html#a7e9c4916081d20435f8f7c2a51b8fdfb", null ]
];