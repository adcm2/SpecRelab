var namespaceSPECNMREADER =
[
    [ "DataColumns", "classSPECNMREADER_1_1DataColumns.html", "classSPECNMREADER_1_1DataColumns" ]
];