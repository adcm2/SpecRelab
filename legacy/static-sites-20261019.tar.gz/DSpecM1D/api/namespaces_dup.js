var namespaces_dup =
[
    [ "DSpecM", "namespaceDSpecM.html", "namespaceDSpecM" ],
    [ "EarthMesh", "namespaceEarthMesh.html", "namespaceEarthMesh" ],
    [ "EarthModels", "namespaceEarthModels.html", "namespaceEarthModels" ],
    [ "Eigen", "namespaceEigen.html", "namespaceEigen" ],
    [ "filters", "namespacefilters.html", [
      [ "hannref", "namespacefilters.html#a41c38393981ec34d7b01173ed3881405", null ],
      [ "hannref", "namespacefilters.html#ab81233b9f3a96ef6c488057c180bf84d", null ]
    ] ],
    [ "Full1D", "namespaceFull1D.html", "namespaceFull1D" ],
    [ "MINEOSREADER", "namespaceMINEOSREADER.html", "namespaceMINEOSREADER" ],
    [ "ModelInfoConcepts", "namespaceModelInfoConcepts.html", "namespaceModelInfoConcepts" ],
    [ "processfunctions", "namespaceprocessfunctions.html", [
      [ "Complex", "namespaceprocessfunctions.html#a1ab5e6e7843bc0d84764e0c357a11831", null ],
      [ "ComplexVector", "namespaceprocessfunctions.html#abbee0dc1437ef9c055c93c5b786c9f54", null ],
      [ "Float", "namespaceprocessfunctions.html#a0f1696ccca59d3a3b5aa03c0f45ca208", null ],
      [ "RealVector", "namespaceprocessfunctions.html#a7ac4136c98f4063ecb80541cbd9d1589", null ],
      [ "filtfreq2time", "namespaceprocessfunctions.html#a1809ac3a3ac8f30010d7a2db77a1008b", null ],
      [ "freq2time", "namespaceprocessfunctions.html#a05c2052da32948c2ec75ab6a795bed75", null ],
      [ "fulltime2freq", "namespaceprocessfunctions.html#aca867ddba68891e74cf71bb777e7d8d9", null ],
      [ "fulltime2freq", "namespaceprocessfunctions.html#ace747607c1eb1986a8252c1d355ea303", null ],
      [ "rawfreq2time", "namespaceprocessfunctions.html#a231d0b035d71141d2f0f034cff2e6bf9", null ],
      [ "rawtime2freq", "namespaceprocessfunctions.html#ab83e40ac6f9f56de4d39a20f0588556f", null ],
      [ "simptime2freq", "namespaceprocessfunctions.html#a0f3d891a71c17f2928ea0883d8d989e4", null ],
      [ "simptime2freq", "namespaceprocessfunctions.html#a05f255f53bfbc36865d27d414f602023", null ]
    ] ],
    [ "SourceInfo", "namespaceSourceInfo.html", "namespaceSourceInfo" ],
    [ "SPARSESPEC", "namespaceSPARSESPEC.html", "namespaceSPARSESPEC" ],
    [ "SPECNMREADER", "namespaceSPECNMREADER.html", "namespaceSPECNMREADER" ],
    [ "SpectralTools", "namespaceSpectralTools.html", "namespaceSpectralTools" ],
    [ "SpectraSolver", "namespaceSpectraSolver.html", "namespaceSpectraSolver" ],
    [ "YSPECREADER", "namespaceYSPECREADER.html", "namespaceYSPECREADER" ]
];