var annotated_dup =
[
    [ "DSpecM", "namespaceDSpecM.html", [
      [ "FilterOptions", "structDSpecM_1_1FilterOptions.html", "structDSpecM_1_1FilterOptions" ],
      [ "FilterResult", "structDSpecM_1_1FilterResult.html", "structDSpecM_1_1FilterResult" ],
      [ "ReferenceTimeSeries", "structDSpecM_1_1ReferenceTimeSeries.html", "structDSpecM_1_1ReferenceTimeSeries" ]
    ] ],
    [ "EarthMesh", "namespaceEarthMesh.html", [
      [ "RadialMesh", "classEarthMesh_1_1RadialMesh.html", "classEarthMesh_1_1RadialMesh" ]
    ] ],
    [ "EarthModels", "namespaceEarthModels.html", [
      [ "EarthConstants", "classEarthModels_1_1EarthConstants.html", "classEarthModels_1_1EarthConstants" ],
      [ "ModelInput", "classEarthModels_1_1ModelInput.html", "classEarthModels_1_1ModelInput" ]
    ] ],
    [ "Eigen", "namespaceEigen.html", [
      [ "FEMPreconditioner", "classEigen_1_1FEMPreconditioner.html", "classEigen_1_1FEMPreconditioner" ]
    ] ],
    [ "Full1D", "namespaceFull1D.html", [
      [ "SEM", "classFull1D_1_1SEM.html", "classFull1D_1_1SEM" ]
    ] ],
    [ "MINEOSREADER", "namespaceMINEOSREADER.html", [
      [ "DataColumns", "classMINEOSREADER_1_1DataColumns.html", "classMINEOSREADER_1_1DataColumns" ]
    ] ],
    [ "SourceInfo", "namespaceSourceInfo.html", [
      [ "EarthquakeCMT", "classSourceInfo_1_1EarthquakeCMT.html", "classSourceInfo_1_1EarthquakeCMT" ]
    ] ],
    [ "SPARSESPEC", "namespaceSPARSESPEC.html", [
      [ "ModeFlags", "structSPARSESPEC_1_1ModeFlags.html", "structSPARSESPEC_1_1ModeFlags" ],
      [ "SparseFSpec", "classSPARSESPEC_1_1SparseFSpec.html", "classSPARSESPEC_1_1SparseFSpec" ],
      [ "SpecConstants", "structSPARSESPEC_1_1SpecConstants.html", "structSPARSESPEC_1_1SpecConstants" ],
      [ "SpectraRunContext", "classSPARSESPEC_1_1SpectraRunContext.html", "classSPARSESPEC_1_1SpectraRunContext" ]
    ] ],
    [ "SPECNMREADER", "namespaceSPECNMREADER.html", [
      [ "DataColumns", "classSPECNMREADER_1_1DataColumns.html", "classSPECNMREADER_1_1DataColumns" ]
    ] ],
    [ "SpectraSolver", "namespaceSpectraSolver.html", [
      [ "FreqFull", "classSpectraSolver_1_1FreqFull.html", "classSpectraSolver_1_1FreqFull" ]
    ] ],
    [ "YSPECREADER", "namespaceYSPECREADER.html", [
      [ "DataColumns", "classYSPECREADER_1_1DataColumns.html", "classYSPECREADER_1_1DataColumns" ]
    ] ],
    [ "InputParameters", "classInputParameters.html", "classInputParameters" ],
    [ "InputParametersNew", "classInputParametersNew.html", "classInputParametersNew" ],
    [ "MeshModel", "classMeshModel.html", "classMeshModel" ],
    [ "ParamInfo", "classParamInfo.html", "classParamInfo" ],
    [ "ParamRedInfo", "classParamRedInfo.html", "classParamRedInfo" ],
    [ "prem_norm", "classprem__norm.html", "classprem__norm" ],
    [ "SiteChanEntry", "classSiteChanEntry.html", "classSiteChanEntry" ],
    [ "SRInfo", "classSRInfo.html", "classSRInfo" ],
    [ "Timer", "classTimer.html", "classTimer" ]
];