var namespaceSPARSESPEC =
[
    [ "ModeFlags", "structSPARSESPEC_1_1ModeFlags.html", "structSPARSESPEC_1_1ModeFlags" ],
    [ "SparseFSpec", "classSPARSESPEC_1_1SparseFSpec.html", "classSPARSESPEC_1_1SparseFSpec" ],
    [ "SpecConstants", "structSPARSESPEC_1_1SpecConstants.html", "structSPARSESPEC_1_1SpecConstants" ],
    [ "SpectraRunContext", "classSPARSESPEC_1_1SpectraRunContext.html", "classSPARSESPEC_1_1SpectraRunContext" ],
    [ "attenFactor", "namespaceSPARSESPEC.html#a42913d249e02a06ea17c4ec15a6edd4e", null ],
    [ "factorizeOrCompute", "namespaceSPARSESPEC.html#a007cb80a6af7ef05fe1d14442f994d19", null ],
    [ "outputFactor", "namespaceSPARSESPEC.html#a041013432989ec8534c81ac27801e3d9", null ],
    [ "resolveModeFlags", "namespaceSPARSESPEC.html#a007c8fd0328a69d5a12646dd395af53b", null ]
];