var namespaceEarthModels =
[
    [ "EarthConstants", "classEarthModels_1_1EarthConstants.html", "classEarthModels_1_1EarthConstants" ],
    [ "ModelInput", "classEarthModels_1_1ModelInput.html", "classEarthModels_1_1ModelInput" ]
];