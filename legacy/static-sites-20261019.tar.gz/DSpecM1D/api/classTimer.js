var classTimer =
[
    [ "Timer", "classTimer.html#a5f16e8da27d2a5a5242dead46de05d97", null ],
    [ "duration_seconds", "classTimer.html#a93237400c37e002507900759e6354527", null ],
    [ "start", "classTimer.html#a3a8b5272198d029779dc9302a54305a8", null ],
    [ "stop", "classTimer.html#a63f0eb44b27402196590a03781515dba", null ],
    [ "stop", "classTimer.html#ae556615fc26f9eb6964d3d20da28115b", null ]
];