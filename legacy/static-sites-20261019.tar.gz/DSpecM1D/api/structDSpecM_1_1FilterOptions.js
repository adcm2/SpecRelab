var structDSpecM_1_1FilterOptions =
[
    [ "enforceRealSignal", "structDSpecM_1_1FilterOptions.html#a99716bb706c19a0687f909734eca8370", null ],
    [ "finalTaper", "structDSpecM_1_1FilterOptions.html#a7b631828f5f93042b994deba1b92be21", null ],
    [ "passes", "structDSpecM_1_1FilterOptions.html#acb5879520f8ef11bdb6a28189bff2b3e", null ],
    [ "preTaper", "structDSpecM_1_1FilterOptions.html#aa5ea6f6a66c8290a19259d00423c76d9", null ]
];