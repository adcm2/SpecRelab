var namespaceDSpecM =
[
    [ "FilterOptions", "structDSpecM_1_1FilterOptions.html", "structDSpecM_1_1FilterOptions" ],
    [ "FilterResult", "structDSpecM_1_1FilterResult.html", "structDSpecM_1_1FilterResult" ],
    [ "ReferenceTimeSeries", "structDSpecM_1_1ReferenceTimeSeries.html", "structDSpecM_1_1ReferenceTimeSeries" ],
    [ "applyFilter", "namespaceDSpecM.html#ace67b3c95c9088eb9adfb7f4ac829b73", null ],
    [ "applyFilter", "namespaceDSpecM.html#a1551f53e31d590a0304f994940cf50f9", null ],
    [ "loadMineosTimeSeries", "namespaceDSpecM.html#a2a8b657cbbee5025c3e90023d0969f66", null ],
    [ "loadReferenceTimeSeries", "namespaceDSpecM.html#a3af8c14a0247dedc29d1dfc2ddbbdc04", null ],
    [ "loadSpecnmTimeSeries", "namespaceDSpecM.html#aa6de2ba06d7b6e418283df3953ed6041", null ],
    [ "loadYSpecTimeSeries", "namespaceDSpecM.html#a722c3c3d55791b58d6b269cb5b5c7d3b", null ],
    [ "writeFrequencyComparison", "namespaceDSpecM.html#af2927cef1462bf76aa32fa13116d4460", null ],
    [ "writeFrequencyComparison", "namespaceDSpecM.html#a791907d3a1f44cf3b87baea9aa2d941e", null ],
    [ "writeFrequencyComparison", "namespaceDSpecM.html#a0e418dbeb01475fe6b6e049f5e4e1989", null ],
    [ "writeFrequencyComparison", "namespaceDSpecM.html#abbeb002beb29dd83e60494defdeb2d82", null ],
    [ "writeTimeComparison", "namespaceDSpecM.html#ae3fac8f7ac031b75a1a19b5f1aa0c354", null ],
    [ "writeTimeComparison", "namespaceDSpecM.html#aecd6d40fc8fb1487b3a9ec2185c5cb49", null ],
    [ "writeTimeSeries", "namespaceDSpecM.html#a0fbfa5f572975cafff5c0c8502e3d5ac", null ],
    [ "writeTimeSeries", "namespaceDSpecM.html#ab669c58ff6ac87fdbaca4d1235946049", null ]
];