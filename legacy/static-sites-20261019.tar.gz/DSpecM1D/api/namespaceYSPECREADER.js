var namespaceYSPECREADER =
[
    [ "DataColumns", "classYSPECREADER_1_1DataColumns.html", "classYSPECREADER_1_1DataColumns" ]
];