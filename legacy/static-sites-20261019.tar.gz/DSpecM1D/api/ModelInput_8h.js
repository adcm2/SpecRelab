var ModelInput_8h =
[
    [ "EarthModels::EarthConstants< FLOAT >", "classEarthModels_1_1EarthConstants.html", "classEarthModels_1_1EarthConstants" ],
    [ "EarthModels::ModelInput< FLOAT, INTEGRAL >", "classEarthModels_1_1ModelInput.html", "classEarthModels_1_1ModelInput" ]
];