var NormClass_8h =
[
    [ "prem_norm< FLOAT >", "classprem__norm.html", "classprem__norm" ],
    [ "I", "NormClass_8h.html#aa80b8601fb6916aa66493a15d5b66010", null ],
    [ "PI", "NormClass_8h.html#a299aabc5fc8285cbf99025330a3d0d0d", null ],
    [ "TWO_PI", "NormClass_8h.html#ad287fa65eb8f5186c28e67f006e84b20", null ]
];