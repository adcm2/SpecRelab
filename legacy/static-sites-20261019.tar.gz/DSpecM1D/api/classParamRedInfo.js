var classParamRedInfo =
[
    [ "ParamRedInfo", "classParamRedInfo.html#a86b967a5f730856a6b87e68d278376f1", null ],
    [ "rvRedSph", "classParamRedInfo.html#afd7d9db26b9ed04c281dba1c640e9dda", null ],
    [ "rvRedTor", "classParamRedInfo.html#a639b297dab04c1d4abb2223a748b5109", null ]
];