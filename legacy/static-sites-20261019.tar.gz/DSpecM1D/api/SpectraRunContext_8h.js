var SpectraRunContext_8h =
[
    [ "SPARSESPEC::SpectraRunContext", "classSPARSESPEC_1_1SpectraRunContext.html", "classSPARSESPEC_1_1SpectraRunContext" ]
];