var namespaceMINEOSREADER =
[
    [ "DataColumns", "classMINEOSREADER_1_1DataColumns.html", "classMINEOSREADER_1_1DataColumns" ]
];