var classprem__norm =
[
    [ "prem_norm", "classprem__norm.html#a77823f08ea7bbcb43fdf8751f8019760", null ],
    [ "LengthNorm", "classprem__norm.html#abae700c777969a51db79654c7002d9e3", null ],
    [ "MassNorm", "classprem__norm.html#aeb983a42d2b75f88c72905554c2e10a5", null ],
    [ "TimeNorm", "classprem__norm.html#a494f50c9ab24d599d459dabbd86af930", null ]
];