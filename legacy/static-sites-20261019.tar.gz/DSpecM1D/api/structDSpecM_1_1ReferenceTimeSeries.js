var structDSpecM_1_1ReferenceTimeSeries =
[
    [ "mineosTime", "structDSpecM_1_1ReferenceTimeSeries.html#af3d935ec61933635e274c94acd0f0187", null ],
    [ "yspecTime", "structDSpecM_1_1ReferenceTimeSeries.html#a86548ffd0be5da313ba3e3aed30d33dc", null ]
];