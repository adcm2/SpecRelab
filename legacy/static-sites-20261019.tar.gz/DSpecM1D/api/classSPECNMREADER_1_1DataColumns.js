var classSPECNMREADER_1_1DataColumns =
[
    [ "DataColumns", "classSPECNMREADER_1_1DataColumns.html#a76948e982a25aea1134e4eaa8b54a87e", null ],
    [ "DataColumns", "classSPECNMREADER_1_1DataColumns.html#a4cdb88829228dd3f9052701cd2f0d50e", null ],
    [ "clear", "classSPECNMREADER_1_1DataColumns.html#a242b5c74f3fc477120a279c9064ea1fd", null ],
    [ "getColumn1", "classSPECNMREADER_1_1DataColumns.html#a94caa5695ba484831f156296466041d7", null ],
    [ "getColumn2", "classSPECNMREADER_1_1DataColumns.html#a0a8c0f88dde63653cc45495e99d5aa5f", null ],
    [ "getColumn3", "classSPECNMREADER_1_1DataColumns.html#ab455236c8351821520acb6ce78e19d14", null ],
    [ "getColumn4", "classSPECNMREADER_1_1DataColumns.html#adc19df1848d6cd73a66473e6029a04c9", null ]
];