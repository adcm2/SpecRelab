var searchData=
[
  ['w0_0',['w0',['../structSPARSESPEC_1_1SpecConstants.html#ae4ed4f9fd27cbb99d24fa7db54c89f86',1,'SPARSESPEC::SpecConstants']]]
];
