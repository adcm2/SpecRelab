var searchData=
[
  ['kappa_0',['kappa',['../classMeshModel.html#a4a09f486491b9797c76661d7b4210aff',1,'MeshModel::Kappa()'],['../classEarthModels_1_1ModelInput.html#a8c9a1cf5232cb2dde4079c1750eefb49',1,'EarthModels::ModelInput::Kappa()']]]
];
