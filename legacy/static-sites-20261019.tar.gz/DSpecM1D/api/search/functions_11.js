var searchData=
[
  ['qkappa_0',['qkappa',['../classMeshModel.html#a4ac061d5b37a3ba7f2cbee5327215e4c',1,'MeshModel::QKappa()'],['../classEarthModels_1_1ModelInput.html#a291311df1eca40f1345ec1599d4ef282',1,'EarthModels::ModelInput::QKappa()']]],
  ['qmu_1',['qmu',['../classMeshModel.html#ab44b711363f0228b6913aa94db24d80b',1,'MeshModel::QMu()'],['../classEarthModels_1_1ModelInput.html#a3b9705b0d3ee0ff3201ba98b56614a2b',1,'EarthModels::ModelInput::QMu()']]]
];
