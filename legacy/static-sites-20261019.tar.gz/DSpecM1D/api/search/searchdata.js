var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwyz~",
  1: "defimprst",
  2: "defmpsy",
  3: "fimnoprst",
  4: "_abcdefghijklmnopqrstuvwyz~",
  5: "efimptwy",
  6: "cfimrsv",
  7: "cm",
  8: "e",
  9: "d",
  10: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enumvalues",
  8: "defines",
  9: "pages",
  10: "concepts"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerator",
  8: "Macros",
  9: "Pages",
  10: "Concepts"
};

