var searchData=
[
  ['jdate_0',['jdate',['../classSiteChanEntry.html#a70719fc59181e6f66c5abf0539c14617',1,'SiteChanEntry']]]
];
