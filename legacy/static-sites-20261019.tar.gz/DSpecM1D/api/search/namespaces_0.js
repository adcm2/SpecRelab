var searchData=
[
  ['dspecm_0',['DSpecM',['../namespaceDSpecM.html',1,'']]]
];
