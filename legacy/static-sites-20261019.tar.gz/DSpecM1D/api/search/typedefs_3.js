var searchData=
[
  ['matrix_0',['MATRIX',['../classSpectraSolver_1_1FreqFull.html#ad4ee23d6c60aa641ba014a42bebee48e',1,'SpectraSolver::FreqFull']]],
  ['myiter_1',['myiter',['../classEarthModels_1_1ModelInput.html#ab48827a1a4b8099e01b2493c970dfd90',1,'EarthModels::ModelInput']]],
  ['myvector_2',['myvector',['../classEarthModels_1_1ModelInput.html#ac742c5bc27861a66db4d60ca1563d770',1,'EarthModels::ModelInput']]]
];
