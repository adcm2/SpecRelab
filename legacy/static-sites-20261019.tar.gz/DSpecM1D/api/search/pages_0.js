var searchData=
[
  ['dspecm1d_0',['DSpecM1D',['../index.html',1,'']]]
];
