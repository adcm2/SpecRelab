var searchData=
[
  ['passes_0',['passes',['../structDSpecM_1_1FilterOptions.html#acb5879520f8ef11bdb6a28189bff2b3e',1,'DSpecM::FilterOptions']]],
  ['pi_1',['PI',['../NormClass_8h.html#a299aabc5fc8285cbf99025330a3d0d0d',1,'NormClass.h']]],
  ['pretaper_2',['preTaper',['../structDSpecM_1_1FilterOptions.html#aa5ea6f6a66c8290a19259d00423c76d9',1,'DSpecM::FilterOptions']]]
];
