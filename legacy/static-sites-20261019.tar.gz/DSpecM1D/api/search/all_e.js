var searchData=
[
  ['n_0',['n',['../classMeshModel.html#a209e50f958fe6cab415ad2c1c6cd0f92',1,'MeshModel::N()'],['../classEarthModels_1_1ModelInput.html#af11d1c9986293bec1fcbf91b3fb1605e',1,'EarthModels::ModelInput::N()']]],
  ['n_5fatten_1',['N_atten',['../classMeshModel.html#aa3cc8337a1be4b2365842c3f3561db86',1,'MeshModel']]],
  ['ne_2',['NE',['../classEarthMesh_1_1RadialMesh.html#ad988c977f969ec110906ba9ce1c5c13c',1,'EarthMesh::RadialMesh']]],
  ['nl_3',['NL',['../classEarthMesh_1_1RadialMesh.html#afb367e4ff7625eddaf2a184b609f4482',1,'EarthMesh::RadialMesh']]],
  ['nn_4',['NN',['../classEarthMesh_1_1RadialMesh.html#a1e0c538b805cd1eee3897f71d9674e68',1,'EarthMesh::RadialMesh']]],
  ['nodegeneratef_5',['nodegenerateF',['../namespaceEarthMesh.html#a894aefb7d70be84c91cc4c2751810b6f',1,'EarthMesh']]],
  ['noderadius_6',['NodeRadius',['../classEarthMesh_1_1RadialMesh.html#a2e89033eacdb98423b66730093f71f38',1,'EarthMesh::RadialMesh']]],
  ['normalisation_7',['Normalisation',['../index.html#autotoc_md6',1,'']]],
  ['normclass_2eh_8',['NormClass.h',['../NormClass_8h.html',1,'']]],
  ['normfactor_9',['normFactor',['../classInputParametersNew.html#a30cd33133650f8c5014a56bf4b53bcbf',1,'InputParametersNew']]],
  ['notes_10',['First Release Notes',['../index.html#autotoc_md7',1,'']]],
  ['nq_11',['nq',['../classInputParametersNew.html#ab32b78a0ab334204a2d91719f9cb37bd',1,'InputParametersNew']]],
  ['nskip_12',['nskip',['../classSPARSESPEC_1_1SpectraRunContext.html#ab7cb42feadf25828d42adca90f45791b',1,'SPARSESPEC::SpectraRunContext::nskip()'],['../classInputParametersNew.html#a58cc4847f3b26e9d4a0a38a22078d0fb',1,'InputParametersNew::nskip()']]],
  ['nt_13',['nt',['../classSpectraSolver_1_1FreqFull.html#a6c43231af125c45db7e753eb63e24ea1',1,'SpectraSolver::FreqFull']]],
  ['nt0_14',['nt0',['../classSpectraSolver_1_1FreqFull.html#af61a91a676d5dff73398bbb15c81de30',1,'SpectraSolver::FreqFull']]],
  ['num_5freceivers_15',['num_receivers',['../classInputParameters.html#ab779d2ab0388b2f38024bcfbfda55b7c',1,'InputParameters']]],
  ['numberoflayers_16',['NumberOfLayers',['../classEarthModels_1_1ModelInput.html#af99b2d85e1f707e111c575b11a962c7b',1,'EarthModels::ModelInput']]]
];
