var searchData=
[
  ['finaltaper_0',['finalTaper',['../structDSpecM_1_1FilterOptions.html#a7b631828f5f93042b994deba1b92be21',1,'DSpecM::FilterOptions']]],
  ['frequencyseries_1',['frequencySeries',['../structDSpecM_1_1FilterResult.html#ad389b2fcca1571c85571dec227a85d12',1,'DSpecM::FilterResult']]]
];
