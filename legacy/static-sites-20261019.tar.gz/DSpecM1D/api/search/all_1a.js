var searchData=
[
  ['_7efreqfull_0',['~FreqFull',['../classSpectraSolver_1_1FreqFull.html#a74043f74e30ddd3940dffcb3e253669e',1,'SpectraSolver::FreqFull']]],
  ['_7esparsefspec_1',['~SparseFSpec',['../classSPARSESPEC_1_1SparseFSpec.html#a659e54fcbb49ca7a72d7c5183861951f',1,'SPARSESPEC::SparseFSpec']]]
];
