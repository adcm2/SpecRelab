var searchData=
[
  ['enforcerealsignal_0',['enforceRealSignal',['../structDSpecM_1_1FilterOptions.html#a99716bb706c19a0687f909734eca8370',1,'DSpecM::FilterOptions']]]
];
