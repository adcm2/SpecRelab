var searchData=
[
  ['datacolumns_0',['datacolumns',['../classMINEOSREADER_1_1DataColumns.html',1,'MINEOSREADER::DataColumns'],['../classSPECNMREADER_1_1DataColumns.html',1,'SPECNMREADER::DataColumns'],['../classYSPECREADER_1_1DataColumns.html',1,'YSPECREADER::DataColumns']]]
];
