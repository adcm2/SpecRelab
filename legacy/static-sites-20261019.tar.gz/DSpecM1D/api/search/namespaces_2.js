var searchData=
[
  ['filters_0',['filters',['../namespacefilters.html',1,'']]],
  ['full1d_1',['Full1D',['../namespaceFull1D.html',1,'']]]
];
