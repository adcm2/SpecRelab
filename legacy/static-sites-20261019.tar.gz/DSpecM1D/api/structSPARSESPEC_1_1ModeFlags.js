var structSPARSESPEC_1_1ModeFlags =
[
    [ "inc_rad", "structSPARSESPEC_1_1ModeFlags.html#af17b33895b00473da7d3e32a4eb97bae", null ],
    [ "inc_sph", "structSPARSESPEC_1_1ModeFlags.html#ace7219e9b30ceeb7b6c5592617ddd6ff", null ],
    [ "inc_tor", "structSPARSESPEC_1_1ModeFlags.html#ae072f3ba28ae47c95ccde6bd7af32a31", null ]
];