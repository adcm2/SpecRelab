var SpecHelpers_8h =
[
    [ "SPARSESPEC::ModeFlags", "structSPARSESPEC_1_1ModeFlags.html", "structSPARSESPEC_1_1ModeFlags" ],
    [ "SPARSESPEC::SpecConstants", "structSPARSESPEC_1_1SpecConstants.html", "structSPARSESPEC_1_1SpecConstants" ],
    [ "attenFactor", "SpecHelpers_8h.html#a42913d249e02a06ea17c4ec15a6edd4e", null ],
    [ "factorizeOrCompute", "SpecHelpers_8h.html#a007cb80a6af7ef05fe1d14442f994d19", null ],
    [ "outputFactor", "SpecHelpers_8h.html#a041013432989ec8534c81ac27801e3d9", null ],
    [ "resolveModeFlags", "SpecHelpers_8h.html#a007c8fd0328a69d5a12646dd395af53b", null ]
];