var classSiteChanEntry =
[
    [ "SiteChanEntry", "classSiteChanEntry.html#a3f1190a96fca080ae8b3bc09c5f586a8", null ],
    [ "azimuth", "classSiteChanEntry.html#a18675f16c3ec2e6385b89578383a795e", null ],
    [ "chanflag", "classSiteChanEntry.html#a79563fa4fb1715732ada6f4a674947c8", null ],
    [ "channel", "classSiteChanEntry.html#a53efbc03cc941b437ae627fab88dbed5", null ],
    [ "description", "classSiteChanEntry.html#aa727ce5f29f8feaf4eceef77d920da89", null ],
    [ "elevation_depth", "classSiteChanEntry.html#a32ba15d1461970ddb1463b2d6f0b12a1", null ],
    [ "jdate", "classSiteChanEntry.html#a70719fc59181e6f66c5abf0539c14617", null ],
    [ "offdate", "classSiteChanEntry.html#a9429aacfc185fbf630cb0e5487e63d11", null ],
    [ "ondate", "classSiteChanEntry.html#a0092189df725de4fb6dc25d80e3d17a5", null ],
    [ "station", "classSiteChanEntry.html#a0fa5dbe9c377b9c99bf398dca5069562", null ],
    [ "timestamp", "classSiteChanEntry.html#a19d2e9f7fd527a4b316984abe865940e", null ],
    [ "zenith", "classSiteChanEntry.html#aef6b70ba08ee3de3bb673e821f672a66", null ]
];