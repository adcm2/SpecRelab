var ModelConcepts_8h =
[
    [ "ModelInfoConcepts::HasBasicNormalisationInformation", "conceptModelInfoConcepts_1_1HasBasicNormalisationInformation.html", null ],
    [ "ModelInfoConcepts::BasicSphericalGeometryModel", "conceptModelInfoConcepts_1_1BasicSphericalGeometryModel.html", null ],
    [ "ModelInfoConcepts::BasicSphericalDensityModel", "conceptModelInfoConcepts_1_1BasicSphericalDensityModel.html", null ]
];